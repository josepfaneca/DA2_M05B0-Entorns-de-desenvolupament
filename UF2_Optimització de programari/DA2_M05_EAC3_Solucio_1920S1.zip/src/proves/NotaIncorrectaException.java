package proves;
/**
 * Excepcio que indica que el valor d'una nota es incorrecta.
 * @author Ramon Cervera
 *
 */

@SuppressWarnings("serial")
public class NotaIncorrectaException extends Exception{
	public NotaIncorrectaException(String missatge) {
        super(missatge);
    }
}