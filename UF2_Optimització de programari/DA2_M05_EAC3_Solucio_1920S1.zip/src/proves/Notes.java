package proves;
/**
 * Classe que cont� m�todes per qualificar l'alumnat d'un institut
 * @author Ramon Cervera
 * @version 1.0.0
 */

public class Notes {

	/**
     * M�tode que converteix una nota num�rica en una qualificaci� textual.
     * @param nota: nota aconseguida per l'alumne.
     * La nota ha der ser un n�mero enter compr�s entre 0 i 10.
     * @throws NotaIncorrectaException si nota no est� entre el rang [0,10]
     * @return Qualificaci� textual aconseguida per l'alumne.
     * 
     */ 
    public static String qualificacio(int nota) throws NotaIncorrectaException{
	      
	if(nota>=0 && nota<=10){
	     if(nota>=9) return "Molt b�";
	     else if(nota>=6) return "B�";
	     else if(nota>=5) return "Normal";
	     else return "Has de millorar";
	}			   
      else throw new NotaIncorrectaException("Nota " + nota + " incorrecta.");         	            
   }	
}