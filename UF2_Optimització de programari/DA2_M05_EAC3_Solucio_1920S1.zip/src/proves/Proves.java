package proves;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Proves {

	@Test
	void test_1() throws NotaIncorrectaException {
		assertThrows(NotaIncorrectaException.class, () -> { 	Notes.qualificacio(-1); 	});
	}	
	@Test
	void test0() throws NotaIncorrectaException {
		
		assertEquals(Notes.qualificacio(0),"Has de millorar");		
	}		
	@Test
	void test4() throws NotaIncorrectaException {
		
		assertEquals(Notes.qualificacio(4),"Has de millorar");		
	}
	@Test
	void test5() throws NotaIncorrectaException {
		
		assertEquals(Notes.qualificacio(5),"Normal");		
	}	
	@Test
	void test7() throws NotaIncorrectaException {
		
		assertEquals(Notes.qualificacio(7),"B�");		
	}	
	@Test
	void test9() throws NotaIncorrectaException {
		
		assertEquals(Notes.qualificacio(9),"Molt b�");		
	}	
	@Test
	void test11() throws NotaIncorrectaException {
		
		assertThrows(NotaIncorrectaException.class, () -> { 
			Notes.qualificacio(11);
			});	
	}
}
