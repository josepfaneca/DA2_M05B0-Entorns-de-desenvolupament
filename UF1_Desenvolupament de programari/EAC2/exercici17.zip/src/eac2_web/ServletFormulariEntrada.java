package eac2_web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletFormulariEntrada
 */
public class ServletFormulariEntrada extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ServletFormulariEntrada() {
// TODO Auto-generated constructor stub
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

//Obtenim els par�metres del formulari

		String nom = request.getParameter("nom");
		String cognoms = request.getParameter("cognoms");
		String DNI = request.getParameter("DNI");
		String telefon = request.getParameter("telefon");
		String dataNaixement = request.getParameter("dataNaixement");

//Preparem la sortida d'aquest m�tode, que ser� una plana HTML

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

//Generaci� de la resposta html

		out.println("<html>");
		out.println("<head><title>Dades introdu�des en el formulari</title></head>");
		out.println("<body>");
		out.println("<h2>Dades del formulari</h2>");
		out.println("<table border=\"0\">");
		out.println("<tr><td><b>Nom:</b></td><td><i>" + nom + "</i></td></tr>");
		out.println("<tr><td><b>Cognoms:</b></td><td><i>" + cognoms + "</i></td></tr>");
		out.println("<tr><td><b>DNI:</b></td><td><i>" + DNI + "</i></td></tr>");
		out.println("<tr><td><b>Tel�fon:</b></td><td><i>" + telefon + "</i></td></tr>");
		out.println("<tr><td><b>Data de naixement:</b></td><td><i>" + dataNaixement + "</i></td></tr>");
		out.println("</table><p>");
		out.println("</body>");
		out.println("</html>");
	}
}
